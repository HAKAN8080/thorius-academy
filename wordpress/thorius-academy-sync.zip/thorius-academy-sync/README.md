# Thorius Academy Sync

WordPress eklentisi — Tutor LMS kursu yayınlandığında veya güncellendiğinde `academy.thorius.com.tr` önbelleğini anında yeniler.

## Kurulum

1. `thorius-academy-sync` klasörünü `wp-content/plugins/` altına yükleyin ve etkinleştirin.
2. **Ayarlar → Thorius Academy Sync** sayfasına gidin.
3. Alanları doldurun:
   - **Etkin**: işaretleyin
   - **Webhook URL**: `https://academy.thorius.com.tr/api/webhooks/wordpress`
   - **Webhook Secret**: Academy `.env` dosyasındaki `WP_WEBHOOK_SECRET` ile aynı değer

## Academy tarafı

`.env` dosyasına ekleyin:

```env
WP_WEBHOOK_SECRET=guclu-rastgele-bir-deger
```

Deploy sonrası endpoint test:

```bash
curl https://academy.thorius.com.tr/api/webhooks/wordpress
```

## Ne zaman tetiklenir?

- Kurs **yayınlandığında** (`course.published`)
- Yayında olan kurs **güncellendiğinde** (`course.updated`) — Tutor LMS Course Builder dahil
- Kurs **taslağa alındığında / yayından kaldırıldığında** (`course.unpublished`)
- Kurs **silindiğinde** (`course.deleted`)

## Fiyat senkronu (Academy vitrin)

Academy kartlarındaki fiyat **Supabase `course_products`** tablosundan okunur; WooCommerce fiyatı otomatik canlı çekilmez.

Webhook şu durumlarda fiyatı Academy'ye yazar:

- Tutor **kursu** kaydedildiğinde / güncellendiğinde (kursa WC ürünü bağlı olmalı: `_tutor_course_product_id`)
- WooCommerce **ürünü** kaydedildiğinde / güncellendiğinde (v1.3.0+) — bağlı kurs varsa fiyat yenilenir

Kurs WooCommerce ürününe bağlı değilse veya hiç webhook gitmemişse Academy'de **Ücretsiz** görünür.

## Not
